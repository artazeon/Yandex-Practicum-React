import React from 'react';
import { Tabs } from './tabs';
import { ProductsContainer } from './products-container';
import { TotalPriceContext, DiscountContext } from '../../services/appContext.js';

export const Cart = () => {

  return (
    <section>
      <Tabs />
      <ProductsContainer />      
    </section>
  );
};
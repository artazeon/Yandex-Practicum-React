import React, { useContext, useState } from 'react';
import styles from './promo-button.module.css';
import closeIcon from '../../images/close.svg';
import { TotalPriceContext, DiscountContext } from '../../services/appContext';
import { DataContext, PromoContext } from '../../services/productsContext';

export const PromoButton = ({ children, extraClass }) => {
  
  const {setDiscount} = useContext(DiscountContext)
  const { promo, setPromo } = useContext(PromoContext); 
  
  const cancelPromo = () => {
    setPromo('');
    setDiscount(null);
  };
  return (
    <button type="button" className={`${styles.button} ${extraClass}`} onClick={cancelPromo}>
      {children}
      <img className={styles.close} src={closeIcon} alt="кнопка закрытия" />
    </button>
  );
};
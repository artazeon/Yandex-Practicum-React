import { combineReducers } from 'redux';
import { cartReducer } from './cart.js';

// Корневой редьюсер
export const rootReducer = combineReducers({
    cartReducer
}) 
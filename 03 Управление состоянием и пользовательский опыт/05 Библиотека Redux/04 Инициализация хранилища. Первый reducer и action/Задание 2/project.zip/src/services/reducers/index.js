import { combineReducers } from 'redux';
import { cartReducer } from './cart';
import {PREVIOUS_STEP, NEXT_STEP} from '../actions/index.js';

const stepReducer = (state = 'cart', action) => {
  switch (action.type) {
    case PREVIOUS_STEP: {
      return state === 'cart'
        ? 'cart'
        : state === 'delivery'
        ? 'cart'
        : state === 'checkout'
        ? 'delivery'
        : 'cart';
    }
    //Раскомментируйте код ниже и опишите шаг PREV_STEP
    case NEXT_STEP: {
      return state === 'cart'
        ? 'delivery'
        : state === 'delivery'
        ? 'checkout'
        : state === 'checkout'
        ? 'checkout'
        : 'checkout';
    }
    default: {
      return state;
    }
  }
};

export const rootReducer = combineReducers({
  cart: cartReducer,
  step: stepReducer
});
export const PREVIOUS_STEP = 'PREVIOUS_STEP';
export const NEXT_STEP = 'NEXT_STEP';
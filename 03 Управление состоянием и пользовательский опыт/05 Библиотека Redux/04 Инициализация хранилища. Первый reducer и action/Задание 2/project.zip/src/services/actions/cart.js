export const INCREASE_ITEM = 'INCREASE_ITEM';
export const DECREASE_ITEM = 'DECREASE_ITEM';
export const DELETE_ITEM = 'DELETE_ITEM';

export const CANCEL_PROMO = 'CANCEL_PROMO';

export const TAB_SWITCH = 'TAB_SWITCH';




